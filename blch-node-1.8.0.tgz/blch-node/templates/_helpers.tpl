{{/*
Create a default fully qualified app name.
Priority: 1) fullNameOverride, 2) .Release.Name if useShortenedChartName, 3) .Release.Name-.Chart.Name
*/}}
{{- define "blch-node.fullname" -}}
{{- if .Values.fullNameOverride }}
{{- .Values.fullNameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .Values.useShortenedChartName }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "blch-node.labels" -}}
app.kubernetes.io/name: {{ include "blch-node.fullname" . }}
{{- $labels := .Values.labels }}
{{- if not $labels }}
{{- $labels = .Values.commonLabels }}
{{- end }}
{{- with $labels }}
{{- toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
Common environment variables for init containers and node container
Based on cosmosfullnode.yaml pod template
*/}}
{{- define "blch-node.containerEnv" -}}
{{- $homeDir := .Values.blch.homeDir -}}
{{- $home := printf "/home/operator/%s" $homeDir -}}
- name: HOME
  value: {{ $home | quote }}
- name: CHAIN_HOME
  value: {{ $home | quote }}
- name: homeDir
  value: {{ $homeDir | quote }}
- name: GENESIS_FILE
  value: {{ printf "%s/config/genesis.json" $home | quote }}
- name: ADDRBOOK_FILE
  value: {{ printf "%s/config/addrbook.json" $home | quote }}
- name: CONFIG_DIR
  value: {{ printf "%s/config" $home | quote }}
- name: DATA_DIR
  value: {{ printf "%s/data" $home | quote }}
{{- with .Values.blch.id }}
- name: CHAIN_ID
  value: {{ . | quote }}
{{- end }}
{{- with .Values.blch.network }}
- name: NETWORK
  value: {{ . | quote }}
{{- end }}
{{- with .Values.blch.binary }}
- name: CHAIN_BINARY
  value: {{ . | quote }}
{{- end }}
- name: NODE_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
{{- end }}

{{/*
Volume mounts for init containers
Based on cosmosfullnode.yaml pod template
*/}}
{{- define "blch-node.initContainerVolumeMounts" -}}
{{- $homeDir := .Values.blch.homeDir -}}
{{- $home := printf "/home/operator/%s" $homeDir -}}
- mountPath: {{ $home | quote }}
  name: pvc
- mountPath: {{ printf "%s/config" $home }}
  name: pvc-config
- mountPath: /tmp
  name: vol-system-tmp
- mountPath: {{ printf "%s/.tmp" $home }}
  name: vol-tmp
- mountPath: {{ printf "%s/.config" $home }}
  name: vol-config
- mountPath: /scripts
  name: vol-scripts
  readOnly: true
{{- end }}

{{/*
Volume mounts for node container
Based on cosmosfullnode.yaml pod template
*/}}
{{- define "blch-node.nodeContainerVolumeMounts" -}}
{{- $homeDir := .Values.blch.homeDir -}}
{{- $home := printf "/home/operator/%s" $homeDir -}}
- mountPath: {{ $home | quote }}
  name: pvc
- mountPath: {{ printf "%s/config" $home }}
  name: pvc-config
- mountPath: /tmp
  name: vol-system-tmp
- mountPath: /scripts
  name: vol-scripts
  readOnly: true
{{- end }}

{{/*
Endpoints configuration
*/}}
{{- define "host" -}}
{{- $context := .context -}}
{{- $endpointName := .endpointName -}}
{{- $name := include "blch-node.fullname" $context }}
{{- if (index $context.Values.endpoints $endpointName).host }}
{{- printf "%s" (index $context.Values.endpoints $endpointName).host }}
{{- else if eq $endpointName "rpc" }}
{{- printf "%s-%s.%s" $name $context.Values.blch.nodeType $context.Values.endpointsBaseDomain }}
{{- else }}
{{- printf "%s-%s-%s.%s" $name $context.Values.blch.nodeType $endpointName $context.Values.endpointsBaseDomain }}
{{- end -}}
{{- end -}}
